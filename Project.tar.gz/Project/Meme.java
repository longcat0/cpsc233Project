//Thanks to Barry Burd from dummies.com for assistance with displaying an image in java
import javax.swing.JFrame;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import java.util.concurrent.ThreadLocalRandom;
import java.util.ArrayList;

public class Meme
{
	public static void main(String args[])
	{
		//ArrayList<ImageIcon> memeList = new ArrayList<ImageIcon>();
		JFrame a = new JFrame();
		String[] memes = new String[]{"meme1.jpg", "meme2.jpg", "meme3.jpg", "meme4.jpg", "meme5.jpg", "meme6.jpg", "meme7.jpg", "meme8.jpg", "meme9.jpg", "meme10.jpg", "meme11.jpg", "meme12.jpg"};
		int index = (int)(Math.random() * (memes.length - 1));
		JLabel b = new JLabel(new ImageIcon(memes[index]));
		a.add(b);
		a.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		a.pack();
		a.setVisible(true);
	}
}